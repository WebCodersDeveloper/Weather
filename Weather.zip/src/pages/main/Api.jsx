

export default function Api() {
  return (
    <div>Api</div>
  )
}
