

// eslint-disable-next-line react/prop-types
export default function Render({region}) {
  return (
    <>
    <div className="box">
        <h1>{region}</h1>
    </div>
    </>
  )
}
