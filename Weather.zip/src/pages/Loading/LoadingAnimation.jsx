
import './LoadingAnimation.css'; // Import your CSS file

const LoadingAnimation = () => {
  


  return (
    <div className="loading-container">
      <div className="loader"></div>
    </div>
  );
};

export default LoadingAnimation;
